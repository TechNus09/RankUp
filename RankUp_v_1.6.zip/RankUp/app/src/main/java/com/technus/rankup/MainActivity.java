package com.technus.rankup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import android.database.Cursor;

import java.util.Arrays;

import static com.technus.rankup.Fetch.k;
import static com.technus.rankup.Fetch.xPlayerNameTXT ;
import static com.technus.rankup.Fetch.xCombatLONG ;
import static com.technus.rankup.Fetch.xMiningLONG ;
import static com.technus.rankup.Fetch.xSmithingLONG ;
import static com.technus.rankup.Fetch.xWoodcuttingLONG;
import static com.technus.rankup.Fetch.xCraftingLONG ;
import static com.technus.rankup.Fetch.xFishingLONG ;
import static com.technus.rankup.Fetch.xCookingLONG ;

import static com.technus.rankup.Fetch.results;

public class MainActivity extends AppCompatActivity {

    String currentSkill;
    public static String userName;
    String result;
    public static  String resultOutput;
    String strLimit;
    String initResultOutput=" Skill :      LVL      |            XP            |      Rank \n" +
            " Combat : 1-0% | 0 | 0 \n" +
            " Mining : 1-0% | 0 | 0 \n" +
            " Smithing : 1-0% | 0 | 0 \n" +
            " Woodcutting : 1-0% | 0 | 0 \n" +
            " Crafting : 1-0% | 0 | 0 \n" +
            " Fishing : 1-0% | 0 | 0 \n" +
            " Cooking : 1-0% | 0 | 0 \n";
    public static int limit;
    int lim;
    public static int[] minLimits ={0,0,0,0,0,0,0};
    public static int[] maxLimits ={0,0,0,0,0,0,0};
    EditText ipUserName;
    EditText ipLimit;
    public static DBHelper DB;
    public static TextView outputResult;
    Button btnSearch,btnHelp,btnClear,btnView,btnAdd,btnDelete;
    String helpTxt = "*Make sure to write your in-game name correctly.\n" +
            "*Search limit must be greater than 0.\n" +
            "*Search limit is the max rank limit the app will search for, if the data of one of the skills remain 0 that mean your rank is lower than the limit, try to set it bigger.\n" +
            "*The app check the players names one by one , the lower your rank is ,the longer the search will be(10s for each 1000 ranks).\n"+
            "tThe second time you search for someone , u don't need to enter a search limit.\n"+
            "The search will become way faster for the second time and go on, so for the first time searching for someone enter a big search limit and let it take its time.\n"+
            "*The app extract the data from the official website, if the app doesn't work:\n"+
                        "     **Check your internet connection.\n"+
                        "     **Check if the website is working.\n"+
                        "     **Check for new updates on github.com/TechNus09/RankUp/releases/.\n"+
            "Note:The website Leaderboard update itself every few minutes (around 5mn) so its data will have 5mn delay than the in-game data.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DB = new DBHelper(this);
        Cursor resTest = DB.getUserData("TestTest");
        if(resTest.getCount()==0){
            DB.insertUserData("TestTest","999","999","999","999","999","999","999");
        }


        ipUserName = findViewById(R.id.ipUserName);
        ipLimit = findViewById(R.id.ipLimit);
        outputResult = findViewById(R.id.outputResult);
        btnSearch = findViewById(R.id.btnSearch);
        btnHelp = findViewById(R.id.btnHelp);
        btnView=findViewById(R.id.btnView);
        btnDelete= findViewById(R.id.btnDelete);




        //show help instructs
        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               CreateAlertDialog();

            }
        });


        // search for player data
        btnSearch.setOnClickListener(v -> {


            outputResult.setText(initResultOutput);

            try { //Registered Name Search
                userName = ipUserName.getText().toString().trim();

            } catch (NullPointerException ex) {
                showToast("please enter a UserName");
                return;
            }
            if (userName.equals("")) {
                showToast("please enter a UserName");
            }


            String[] playersNames = DB.GetNamesList();
            if (Arrays.asList(playersNames).contains(userName)){
                Cursor res = DB.getUserData(userName);
                int[] ranks= {0,0,0,0,0,0,0};
                int i;
                while(res.moveToNext()){
                    for (i=1;i<8;i++) {
                        int temp = Integer.parseInt(res.getString(i));
                        ranks[i-1]=temp;
                    }
                }
                int j;
                for (j=0;j<7;j++){
                    minLimits[j]=SpeedUp.minLimit(ranks[j]);
                    maxLimits[j]=SpeedUp.maxLimit(ranks[j]);
                }
                //showToast("Searching...");
                Fetch process = new Fetch(getApplicationContext());
                process.execute();
                Toast.makeText(MainActivity.this, "Searching and Updating "+userName+" Data.", Toast.LENGTH_SHORT).show();



//
            }
            else{ //Fresh Search
                try {
                    userName = ipUserName.getText().toString().trim();

                } catch (NullPointerException ex) {
                    showToast("please enter a UserName");
                    return;
                }
                if (userName.equals("")) {
                    showToast("please enter a UserName");
                }
                try {
                    strLimit = ipLimit.getText().toString().trim();
                    lim = Integer.parseInt(strLimit);
                    limit = (lim / 20) + 1;
                } catch (NumberFormatException ex) {
                    showToast("please enter a valid number");
                    return;
                }

                int i;
                for (i=0;i<7;i++){
                    minLimits[i]=limit;
                    maxLimits[i]=0;
                }
                //showToast("Searching...");
                Fetch process = new Fetch(getApplicationContext());
                process.execute();

                Toast.makeText(MainActivity.this, "Searching and Registering "+userName+" Data.", Toast.LENGTH_SHORT).show();


            }

        });

        //display username's data
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    userName = ipUserName.getText().toString().trim();

                } catch (NullPointerException ex) {
                    showToast("please enter a UserName");
                    return;
                }

                Cursor res = DB.getUserData(userName);
                if ((userName == null) || (userName.equals(""))){
                    Toast.makeText(MainActivity.this, "Please Enter a UserName", Toast.LENGTH_SHORT).show();
                }
                else if(res.getCount()==0){
                    Toast.makeText(MainActivity.this, "Username Not Registered", Toast.LENGTH_SHORT).show();
                }
                else if (res.getCount()!=0){
                    StringBuilder buffer = new StringBuilder();
                    while(res.moveToNext()){
                        buffer.append("PlayerName :").append(res.getString(0)).append("\n");
                        buffer.append("Combat :").append(res.getString(1)).append("\n");
                        buffer.append("Mining :").append(res.getString(2)).append("\n");
                        buffer.append("Smithing :").append(res.getString(3)).append("\n");
                        buffer.append("Woodcutting :").append(res.getString(4)).append("\n");
                        buffer.append("Crafting :").append(res.getString(5)).append("\n");
                        buffer.append("Fishing :").append(res.getString(6)).append("\n");
                        buffer.append("Cooking :").append(res.getString(7)).append("\n\n");
                    }

                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setCancelable(true);
                    builder.setTitle(userName+"'s Ranks");
                    builder.setMessage(buffer.toString());
                    builder.show();
                }

            }
        });

        //deleting username's data
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    userName = ipUserName.getText().toString().trim();

                } catch (NullPointerException ex) {
                    showToast("please enter a UserName");
                    return;
                }
                DB.deleteUserData(userName);
            }
        });






    }

    private void CreateAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("how to use me");
        builder.setMessage(helpTxt);
        builder.show();
    }

    public void showToast(String text) {
        Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
    }

}