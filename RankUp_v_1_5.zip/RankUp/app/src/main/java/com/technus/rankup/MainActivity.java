package com.technus.rankup;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import static com.technus.rankup.Fetch.results;

public class MainActivity extends AppCompatActivity {

    String currentSkill;
    public static String userName;
    String result;
    public static  String resultOutput;
    String strLimit;
    public static int limit;
    int lim;
    EditText ipUserName;
    EditText ipLimit;
    public static TextView outputResult;
    Button btnSearch,btnHelp,btnClear;
    String helpTxt = "*Make sure to write your in-game name correctly.\n" +
            "*Search limit must be greater than 0.\n" +
            "*Search limit is the max rank limit the app will search for, if the data of one of the skills remain 0 that mean your rank is lower than the limit, try to set it bigger.\n" +
            "*The app check the players names one by one , the lower your rank is ,the longer the search will be(10s for each 1000 ranks).\n"+
            "*The app extract the data from the official website, if the app doesn't work:\n"+
            "*For new search, clear the results display with (Clear) then start the new search.\n"+
                        "     **Check your internet connection.\n"+
                        "     **Check if the website is working.\n"+
                        "     **Check for new updates on github.com/TechNus09/RankUp/releases/.\n"+
            "Note:The website update itself every few minutes (around 5mn) so its data will have 5mn delay than the in-game data.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ipUserName = findViewById(R.id.ipUserName);
        ipLimit = findViewById(R.id.ipLimit);
        outputResult = findViewById(R.id.outputResult);
        btnSearch = findViewById(R.id.btnSearch);
        btnHelp = findViewById(R.id.btnHelp);
        btnClear = findViewById(R.id.btnClear);

        //show help instructs
        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               CreateAlertDialog();

            }
        });


        // search for player data
        btnSearch.setOnClickListener(v -> {
            try {
                userName = ipUserName.getText().toString();
            }
            catch (NullPointerException ex) {
                showToast("please enter a UserName");
                return;
            }
            if (userName.equals(""))
                showToast("please enter a UserName");
            try {
                strLimit = ipLimit.getText().toString();
                lim = Integer.parseInt(strLimit);
                limit = (lim / 20) + 1;
            }
            catch (NumberFormatException ex) {
                showToast("please enter a valid number");
                return;
            }

            showToast("Searching...");
            Fetch process = new Fetch();
            process.execute();

        });

        // clear results display
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resultOutput=" -------RESULT-------\n" +
                        " Skill :      LVL      |            XP            |      Rank \n" +
                        " Combat : 1-0% | 0 | 0 \n" +
                        " Mining : 1-0% | 0 | 0 \n" +
                        " Smithing : 1-0% | 0 | 0 \n" +
                        " Woodcutting : 1-0% | 0 | 0 \n" +
                        " Crafting : 1-0% | 0 | 0 \n" +
                        " Fishing : 1-0% | 0 | 0 \n" +
                        " Cooking : 1-0% | 0 | 0 \n";
                outputResult.setText(resultOutput);
            }
        });

    }


    private void CreateAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("how to use me");
        builder.setMessage(helpTxt);
        builder.show();
    }

    public void showToast(String text) {
        Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG).show();
    }

}